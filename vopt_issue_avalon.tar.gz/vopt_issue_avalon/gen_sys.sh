#!/bin/sh
qsys-script --script=my_sys.tcl --quartus-project=top

qsys-generate my_sys.qsys --quartus-project=top -rev=top --clear-output-directory --parallel=off -simulator=MODELSIM -synthesis=Verilog -simulation=Verilog

